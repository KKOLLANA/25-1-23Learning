import java.util.Scanner;

public class detect {
	public static void main (String[] args) {
		System.out.println("enter the integer  :");
		Scanner sc = new Scanner(System.in);
//		System.out.println(sc.nextInt());
//		System.out.println(s);
		System.out.println(sc.hasNextInt());
			
		}
		
		
	}

