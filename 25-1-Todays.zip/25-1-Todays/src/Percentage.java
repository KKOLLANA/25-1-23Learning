import java.util.Scanner;

public class Percentage {

	public static void main(String[] args) {
		
		System.out.println("Enter the marks :");
		
	Scanner sc = new Scanner(System.in);
	System.out.println(" Enter the Physics marks:");
	float Physics = sc.nextFloat();
	System.out.println(" Enter the Maths marks:");
	float Maths = sc.nextFloat();
	System.out.println(" Enter the English marks:");
	float English = sc.nextFloat();
	System.out.println(" Enter the Hindi marks:");
	float Hindi = sc.nextFloat();
	System.out.println(" Enter the Science marks:");
	float Science = sc.nextFloat();
	
	float Per = ((Physics + Maths + English + Hindi + Science)/500.0f)*100;
	System.out.println(Per);

	}

}
