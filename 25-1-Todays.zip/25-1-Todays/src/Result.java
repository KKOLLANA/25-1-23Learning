
public class Result {

	public static void main(String[] args) {
		
		float b=7;
		float c = 4;
		float d=9;
		float e = 2;
//		one way
//		float a = (b/c) * (d/e);
		
		float a= 7/4.0f * 9/2.0f;
		System.out.println(a);

	}

}
