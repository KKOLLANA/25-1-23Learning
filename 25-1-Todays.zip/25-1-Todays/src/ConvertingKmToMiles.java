import java.util.Scanner;

public class ConvertingKmToMiles {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);		
		
	System.out.println("Enter the distance in KM :");
	float Km = sc.nextFloat();
	float miles = (float) (0.6213711922 * Km);
	
	System.out.println("Distance in miles will be :"+miles);
	
	
	
	}
	}
