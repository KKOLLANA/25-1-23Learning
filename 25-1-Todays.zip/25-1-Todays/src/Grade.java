
public class Grade {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 char grade = 'B';
 
// Encoding the grade
 grade = (char)(grade + 9);
 System.out.println(grade);
 
// Decrypting the grade
 
 
 grade = (char)(grade - 9);
 System.out.println(grade);

	}

}
